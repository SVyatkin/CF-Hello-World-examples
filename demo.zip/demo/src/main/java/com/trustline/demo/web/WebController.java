package com.trustline.demo.web;

import java.awt.List;
import java.io.IOException;
import java.util.Date;
import java.util.UUID;
import java.util.Vector;

import javax.net.ssl.SSLEngineResult.Status;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.trustline.demo.config.Configuration;
import com.trustline.demo.dto.Payment;
import com.trustline.demo.service.RestClient;

@ComponentScan
@RestController
@CrossOrigin()
public class WebController {

	@Autowired
	RestClient restClient;

	private static final Logger log = LoggerFactory.getLogger(WebController.class);

	public static final String PAY = "/pay/{payment}";

	private static final String DEPOSIT = "/deposit/{payment}";

	private Vector<Payment> balance = new Vector<Payment>();

	private static String unprocessedPayment = ": payment is not processed";

	/**
	 * Transfer payment to partner
	 */

	@RequestMapping(value = PAY, method = RequestMethod.GET)
	public String payment(@PathVariable double payment) throws JsonParseException, JsonMappingException, IOException {
		UUID confirmationNumber = UUID.randomUUID();

		// deposit payment to partner

		ResponseEntity<String> code = restClient.callGet(Configuration.partnerUrl + "/pay/" + payment);

		String responseMessage;
		if (code.getStatusCode() == HttpStatus.OK) {
			balance.add(new Payment(confirmationNumber.toString(), code.getBody(), -payment, new Date()));
			responseMessage = confirmationNumber.toString();
		} else
			responseMessage = code.getStatusCode() + unprocessedPayment;

		return responseMessage;
	}

	/**
	 * Deposit payment from partner
	 */

	@RequestMapping(value = DEPOSIT, method = RequestMethod.GET)
	public String deposit(@PathVariable double payment) throws JsonParseException, JsonMappingException, IOException {
		UUID confirmationNumber = UUID.randomUUID();

		return confirmationNumber.toString();
	}

}