package com.trustline.demo.config;

import org.springframework.beans.factory.annotation.Value;

public class Configuration {
	
	@Value("${com.trustline.partner.url}")
	public static String partnerUrl;	
	
	@Value("${com.trustline.partner.name}")
	public static String partnerName;	
	
}
