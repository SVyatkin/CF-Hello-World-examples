package com.trustline.demo.dto;

import java.util.Date;

public class Payment {
	String confirmationNumber;
	String confirmationNumberBeneficar;
	Date date;
	double payment;
	
	public Payment(String confirmationNumber, String confirmationNumberBeneficar, double payment, Date date) {
		this.confirmationNumber = confirmationNumber;
		this.confirmationNumberBeneficar = confirmationNumberBeneficar;
		this.payment = payment;
		this.date = date;
	}
	public String getConfirmationNumber() {
		return confirmationNumber;
	}
	public void setConfirmationNumber(String confirmationNumber) {
		this.confirmationNumber = confirmationNumber;
	}
	public String getConfirmationNumberBeneficar() {
		return confirmationNumberBeneficar;
	}
	public void setConfirmationNumberBeneficar(String confirmationNumberBeneficar) {
		this.confirmationNumberBeneficar = confirmationNumberBeneficar;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public double getPayment() {
		return payment;
	}
	public void setPayment(double payment) {
		this.payment = payment;
	}
}
